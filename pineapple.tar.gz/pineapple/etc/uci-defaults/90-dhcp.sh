#!/bin/ash

. /lib/functions.sh

HAK5_VERSION=100

handle_dnsmasq() {
	config_get hak5v $1 hak5ver 0
	if test $hak5v -lt $HAK5_VERSION; then
		uci set dhcp.$1.rebind_protection=0
		uci set dhcp.$1.local=''
		uci set dhcp.$1.domain=''
	fi
}

config_load dhcp
config_foreach handle_dnsmasq dnsmasq

config_get cli cli interface notfound
if test "$cli" = "notfound"; then
	uci set dhcp.cli=dhcp
	uci set dhcp.cli.hak5ver="$HAK5_VERSION"
	uci set dhcp.cli.interface='cli'
	uci set dhcp.cli.ignore='1'
fi

config_get wan wan interface notfound
if test "$wan" = "notfound"; then
	uci set dhcp.wan=dhcp
	uci set dhcp.wan.hak5ver="$HAK5_VERSION"
	uci set dhcp.wan.interface='wan'
	uci set dhcp.wan.ignore='1'
fi

config_get wwan wwan interface notfound
if test "$wwan" = "notfound"; then
	uci set dhcp.wwan=dhcp
	uci set dhcp.wwan.hak5ver="$HAK5_VERSION"
	uci set dhcp.wwan.interface='wwan'
	uci set dhcp.wwan.ignore='1'
fi

config_get eth eth interface notfound
if test "$eth" = "notfound"; then
	uci set dhcp.eth=dhcp
	uci set dhcp.eth.hak5ver="$HAK5_VERSION"
	uci set dhcp.eth.interface='eth'
	uci set dhcp.eth.ignore='1'
fi

uci commit dhcp

cp /etc/init.d/dnsmasq.hak5 /etc/init.d/dnsmasq
rm /etc/rc.d/S19dnsmasq.hak5

grep '/tmp/dnsmasq.address' /etc/dnsmasq.conf
if test $? -ne 0; then
	echo "conf-file=/tmp/dnsmasq.address" >> /etc/dnsmasq.conf
fi

service enable dnsmasq

exit 0
