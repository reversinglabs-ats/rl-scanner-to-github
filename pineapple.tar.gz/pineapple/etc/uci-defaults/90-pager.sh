#!/bin/ash

. /lib/functions.sh

HAK5_VERSION=100

uci get 'system.@pager[0]' 1>/dev/null 2>/dev/null || {
uci batch <<EOF
add system pager
set system.@pager[-1].vibrate='1'
set system.@pager[-1].vibe_with_audio='1'
set system.@pager[-1].volume='100'
set system.@pager[-1].lcd_brightness='16'
set system.@pager[-1].lcd_timeout='60'
set system.@pager[-1].theme='wargames'
set system.@pager[-1].boot_ringtone='Hak5 The Planet:d=4,o=5,b=450:c6,c6,g5,c6,p,g5,a#5,c6,p,f5,g5,a#5,c6'
set system.@pager[-1].alert_ringtone='Alert:d=16,o=5,b=400:c'
set system.@pager[-1].battery_low='Battery Low:d=4,o=6,b=400:c6,p,c5,p,2c4'
set system.@pager[-1].battery_crit='Battery Critical:d=4,o=6,b=300:c,p,c,p,c,p,c,p,c,p,c'
set system.@pager[-1].power_connect='Power Connected:d=16,o=6,b=300:c4,p,c5'
set system.@pager[-1].power_discon='power_disconnect'
set system.@pager[-1].led_color='magenta'
set system.@pager[-1].power_disconnect='Power Disconnected:d=16,o=6,b=300:c5,p,c4'
set system.@pager[-1].payload_complete='LEVEL DONE:d=16,o=4,b=200:8e4,8g4,8a#4,8d5,8b6'
set system.@pager[-1].error='Error:d=16,o=4,b=285:a,b,a,b,a,b,a,16p,c,d,c,d,c,d,c'
set system.@pager[-1].dim_brightness='5'
set system.@pager[-1].dim_timeout='15'
commit system
EOF
}

