
service umount disable
service shutdown enable
