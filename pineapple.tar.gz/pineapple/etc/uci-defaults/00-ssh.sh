
/etc/init.d/sshd start
/etc/init.d/sshd enable
