#!/bin/ash

. /lib/functions.sh

HAK5_VERSION=100

handle_system() {
	config_get hak5v $1 hak5ver 0
	if test $hak5v -lt $HAK5_VERSION; then
		uci set system.$1.hostname='pager'
		uci set system.$1.hak5ver="$HAK5_VERSION"
		echo 'pager' > /proc/sys/kernel/hostname
	fi
}

config_load "system"

config_foreach handle_system system

uci commit system
