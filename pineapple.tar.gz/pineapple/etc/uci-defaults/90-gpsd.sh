#!/bin/ash

uci set gpsd.core.enabled='1'
uci commit

service enable gpsd

exit 0
