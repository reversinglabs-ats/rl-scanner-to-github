#!/bin/ash

# fix ssh-copy-id client-side hard coding openwrt behavior wrong

mkdir -p /etc/dropbear/
rm -f /etc/dropbear/authorized_keys
chmod 700 root
mkdir -p /root/.ssh
chmod 0700 /root/.ssh
touch /root/.ssh/authorized_keys
chmod 0600 /root/.ssh/authorized_keys
ln -s /root/.ssh/authorized_keys /etc/dropbear/authorized_keys

exit 0
