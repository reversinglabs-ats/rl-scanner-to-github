#!/bin/ash

if [ ! -L /root ]; then
    rm -rf /root
    ln -s /mmc/root /root
fi

