#!/bin/ash

. /lib/functions.sh

FOUND_SDA_MOUNT=0
FOUND_MMC_MOUNT=0

handle_mount() {
    config_get dev $1 device na
    if test "$dev" = "/dev/sda1"; then
        FOUND_SDA_MOUNT=1
    fi
    if test "$dev" = "/dev/mmcblk0p1"; then
        FOUND_MMC_MOUNT=1
    fi
}

# mmc is formatted and mounted on-demand in the early boot loader
# if test $FOUND_MMC_MOUNT -ne 1; then
#     uci add fstab mount
#     uci set fstab.@mount[-1].device='/dev/mmcblk0p1'
#     uci set fstab.@mount[-1].target='/mmc'
#     uci set fstab.@mount[-1].autofs='1'
#     uci set fstab.@mount[-1].enabled='1'
#     uci set fstab.@mount[-1].options='noatime'
#     uci commit fstab
# fi

if test $FOUND_SDA_MOUNT -ne 1; then
    # Add USB mounts to our defaults
    uci add fstab mount
    uci set fstab.@mount[-1].device='/dev/sda1'
    uci set fstab.@mount[-1].target='/usb'
    uci set fstab.@mount[-1].autofs='1'
    uci set fstab.@mount[-1].enabled='1'
    uci set fstab.@mount[-1].options='noatime'
    uci commit fstab
fi

/etc/init.d/blockd enable

exit 0
