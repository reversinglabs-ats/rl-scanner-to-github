#!/bin/ash

rm /etc/init.d/S93triggerhappy

exit 0
