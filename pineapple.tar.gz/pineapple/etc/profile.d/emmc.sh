export LD_LIBRARY_PATH="/mmc/lib:/mmc/usr/lib:$LD_LIBRARY_PATH"
export PATH="/mmc/bin:/mmc/sbin:/mmc/usr/bin:/mmc/usr/sbin:$PATH"
