# payload utility functions
