
. /usr/share/libubox/jshn.sh

HTTP_STATUS_CODE=0
HTTP_BODY=""
API_ERROR=""

# USAGE [minimum number of args] "$@"
# Handles help and processes the minimum number of arguments.  More
# arguments are permitted.
USAGE() {
	local __minargs=$1
	shift
	if [ "$1" == "-h" -o "$1" == "--help" -o $# -lt ${__minargs} ]; then usage; fi
}

# EXACT_USAGE [number of args] "$@"
# Handled help and processes an exact number of required arguments.
# More arguments are NOT permitted.
EXACT_USAGE() {
	local __nargs=$1
	shift
	if [ "$1" == "-h" -o "$1" == "--help" -o $# -ne ${__nargs} ]; then usage; fi
}

# DOCLINK [stub url]
# Generates a document URL to be used in a usage() function
DOCLINK() {
	local __name="$1"

	echo
	echo "For complete documentation, see the Pineapple Pager guide at"
	echo "https://hak5.org/products/pineapple/pineapplepager/${__name}"
	echo
}

# SAFE_JSON_STRING [data]
# Use the 'jq' tool to escape a string so that it can be included in JSON
SAFE_JSON_STRING() {
    echo -n "$*" | jq -R -s '.'
}
# Faster in proc version - (reverted) might require calling script changes
#SAFE_JSON_STRING() {
#    printf '%s' "$*" | sed \
#        -e 's/\\/\\\\/g' \
#        -e 's/"/\\"/g' \
#        -e 's/\r/\\r/g' \
#        -e 's/\t/\\t/g' \
#        -e ':a;N;$!ba;s/\n/\\n/g' \
#        -e '1s/^/"/' -e '$s/$/"/'
#}

# VALIDATE_MAC [mac]
# Matches against valid MAC address formats

VALIDATE_MAC() {
	local __mac="$1"

	if ! [[ "${__mac}" =~ ^([a-fA-F0-9]{2}:){5}[a-fA-F0-9]{2}$ ]]; then
		echo "invalid MAC address"
		return 1
	fi

	return 0
}

# VALIDATE_UNSIGNED [int]
# Validates if a value is a positive number
VALIDATE_UNSIGNED() {
    local __unsigned="$1"

    if ! [[ "${__unsigned}" =~ ^[0-9]+$ ]]; then
        echo "invalid number"
        return 1
    fi

    return 0
}

# VALIDATE_PORT [port]
# Matches against valid port number ranges
VALIDATE_PORT() {
    local __port="$1"

	if ! [[ "${__port}" =~ ^[0-9]+$ ]]; then
		echo "invalid port"
		return 1
	fi

    if [ "${__port}" -lt 1 -o "${__port}" -gt 65536 ]; then
        echo "invalid port"
        return 1
    fi

    return 0
}

# HAK5_API_PRINT_JSON_ERROR [content]
# Load a JSON response from the backend server and print the error field,
# if present.
HAK5_API_PRINT_JSON_ERROR() {
	local __body="$1"

	json_init
	json_load "${__body}" >/dev/null 2>/dev/null
	json_get_var err 'error'
	if [ "${err}"x != "x" ]; then echo ${err}; return; fi

	echo "Unknown error"
}

# HAK5_API_PUT [uri] [put content]
# Execute a HTTP PUT with (optional) content data over the local unix
# interface.
#
# The response is processed using jshn and is available as the active
# jshn structure upon return.
#
# Return:
#   0           success
#   non-zero    failure, error printed to stdout
HAK5_API_PUT() {
	local __uri="http://localhost/api/${1}"
	local __data="$2"
	local __rc

	if [ "$HAK5_API_VERBOSE"x = "1x" ]; then
		echo "DEBUG: $__uri"
		echo "DEBUG: $__data"
	fi

	IFS=$'\n' read -r -d '' HTTP_STATUS_CODE HTTP_BODY < \
		<(curl --unix-socket /tmp/api.sock -X PUT -d "${__data}" -s -w "%{http_code}\n" -o \
		>(IFS= read -r -d '' -u0 stdin; printf "%s"  "$stdin") $__uri)

	__rc=$?

	if [ $__rc -ne 0 ]; then
		if [ "$HAK5_API_VERBOSE"x = "1x" ]; then
			echo "DEBUG: rc $__rc [$HTTP_STATUS_CODE] $HTTP_BODY"
		fi

		if [ $HTTP_STATUS_CODE -eq 400 ]; then
			echo -n "Malformed API request: "
			HAK5_API_PRINT_JSON_ERROR "$HTTP_BODY"
		elif [ $HTTP_STATUS_CODE -eq 403 ]; then
			echo "API access prohibited"
		elif [ $HTTP_STATUS_CODE -eq 404 ]; then
			echo "API not supported on this platform"
		elif [ $HTTP_STATUS_CODE -eq 500 ]; then
			echo -n "Server error processing request: "
			HAK5_API_PRINT_JSON_ERROR "$HTTP_BODY"
		fi

        # handle rc1 but http 200 not being an error
        if [ $HTTP_STATUS_CODE -ne 200 ]; then
		    return $__rc
        fi
	fi

	json_init
	json_load "${HTTP_BODY}" >/dev/null 2>/dev/null
	json_get_var err 'error'
	if [ "${err}"x != "x" ]; then API_ERROR="${err}"; return 1; fi

	return 0
}

# HAK5_API_POST [uri] [post content]
# Execute a HTTP POST with (optional) content data over the local unix
# interface.
#
# The response is processed using jshn and is available as the active
# jshn structure upon return.
#
# Return:
#   0           success
#   non-zero    failure, error printed to stdout
HAK5_API_POST() {
	local __uri="http://localhost/api/${1}"
	local __data="$2"
	local __rc

	if [ "$HAK5_API_VERBOSE"x = "1x" ]; then
		echo "DEBUG: $__uri"
		echo "DEBUG: $__data"
	fi

	IFS=$'\n' read -r -d '' HTTP_STATUS_CODE HTTP_BODY < \
		<(curl --unix-socket /tmp/api.sock -X POST -d "${__data}" -s -w "%{http_code}\n" -o \
		>(IFS= read -r -d '' -u0 stdin; printf "%s"  "$stdin") $__uri)

	__rc=$?

	if [ $__rc -ne 0 ]; then
		if [ "$HAK5_API_VERBOSE"x = "1x" ]; then
			echo "DEBUG: rc $__rc [$HTTP_STATUS_CODE] $HTTP_BODY"
		fi

		if [ $HTTP_STATUS_CODE -eq 400 ]; then
			echo -n "API request failed: "
			HAK5_API_PRINT_JSON_ERROR "$HTTP_BODY"
		elif [ $HTTP_STATUS_CODE -eq 403 ]; then
			echo "API access prohibited"
		elif [ $HTTP_STATUS_CODE -eq 404 ]; then
			echo "API not supported on this platform"
		elif [ $HTTP_STATUS_CODE -eq 500 ]; then
			echo -n "Server error processing request: "
			HAK5_API_PRINT_JSON_ERROR "$HTTP_BODY"
		fi

        # handle rc1 but http 200 not being an error
        if [ $HTTP_STATUS_CODE -ne 200 ]; then
		    return $__rc
        fi
	fi

	json_init
	json_load "${HTTP_BODY}"
	json_get_var err 'error'
	if [ "${err}"x != "x" ]; then API_ERROR="${err}"; return 1; fi

	return 0
}

# HAK5_API_POST [uri]
# Execute a HTTP GET over the local unix interface.
#
# The response is processed using jshn and is available as the active
# jshn structure upon return.
#
# Return:
#   0           success
#   non-zero    failure, error printed to stdout
HAK5_API_GET() {
	local __uri="http://localhost/api/${1}"
	local __rc

	if [ "$HAK5_API_VERBOSE"x = "1x" ]; then
		echo "DEBUG: $__uri"
	fi

	IFS=$'\n' read -r -d '' HTTP_STATUS_CODE HTTP_BODY < \
		<(curl --unix-socket /tmp/api.sock -X GET -s -w "%{http_code}\n" -o \
		>(IFS= read -r -d '' -u0 stdin; printf "%s"  "$stdin") $__uri)

	__rc=$?

	if [ $__rc -ne 0 ]; then
		if [ "$HAK5_API_VERBOSE"x = "1x" ]; then
			echo "DEBUG: rc $__rc [$HTTP_STATUS_CODE] $HTTP_BODY"
		fi

		if [ $HTTP_STATUS_CODE -eq 400 ]; then
			echo -n "Malfored API request: "
			HAK5_API_PRINT_JSON_ERROR "$HTTP_BODY"
		elif [ $HTTP_STATUS_CODE -eq 403 ]; then
			echo "API access prohibited"
		elif [ $HTTP_STATUS_CODE -eq 404 ]; then
			echo "API not supported on this platform"
		elif [ $HTTP_STATUS_CODE -eq 500 ]; then
			echo -n "Server error processing request: "
			HAK5_API_PRINT_JSON_ERROR "$HTTP_BODY"
		fi

        # handle rc1 but http 200 not being an error
        if [ $HTTP_STATUS_CODE -ne 200 ]; then
		    return $__rc
        fi
	fi

	json_init
	json_load "${HTTP_BODY}"
	json_get_var err 'error'
	if [ "${err}"x != "x" ]; then API_ERROR="${err}"; return 1; fi

	return 0
}


# NEW_MAP [name]
#
# Prepares a new mapping in memory of key:value pairs, used in
# configurations, payloads, and other areas
NEW_MAP() {
    local __k=_map_${1}_k
    local __v=_map_${1}_v

    declare -ga ${__k}
    declare -ga ${__v}

    eval "${__k}=()"
    eval "${__v}=()"
}

# ADD_MAP [name] [key] [value]
#
# Adds to an existing mapping
ADD_MAP() {
    local __pk=_map_${1}_k
    local __pv=_map_${1}_v
    local __k=${2}
    local __v=${3}

    eval "${__pk}+=(\$__k)"
    eval "${__pv}+=(\$__v)"
}

# MAP_TO_JSON_2DARRAY [name]
#
# Convert a map to a flat 2d JSON array of
# [ [k1,v1], [k2,v2], ..., [kN,vN] ]
#
# Returns as string, to be captured with $(..)
MAP_TO_JSON_2DARRAY() {
    local __pk=_map_${1}_k
    local __pv=_map_${1}_v

    eval "local __l=\${#${__pk}[@]}"
    eval "local __pk_v=(\${${__pk}[@]})"
    eval "local __pv_v=(\${${__pv}[@]})"

    echo -n "["

    if test ${__l} -ge 1; then
        echo -n "[\"${__pk_v[0]}\", \"${__pv_v[0]}\"]"
    fi

    for (( i = 1; i < ${__l}; i++ )); do
        echo -n ",[\"${__pk_v[$i]}\", \"${__pv_v[$i]}\"]"
    done

    echo -n "]"
}

# MAP_TO_JSON_MAP [name]
#
# Convert a map to a flat JSON dictionary of
# { k1: v1, k2: v2, ..., kN: vN }
#
# Keys are always quoted strings due to a restriction
# of the JSON dictionary.  Values are always quoted strings.
#
# Returns as string, to be captured with $(..)
MAP_TO_JSON_MAP() {
    local __pk=_map_${1}_k
    local __pv=_map_${1}_v

    eval "local __l=\${#${__pk}[@]}"
    eval "local __pk_v=(\${${__pk}[@]})"
    eval "local __pv_v=(\${${__pv}[@]})"

    echo -n "{"

    if test ${__l} -ge 1; then
        echo -n "\"${__pk_v[0]}\": \"${__pv_v[0]}\""
    fi

    for (( i = 1; i < ${__l}; i++ )); do
        echo -n ",\"${__pk_v[$i]}\": \"${__pv_v[$i]}\""
    done

    echo -n "}"
}

# NEW_LIST [name]
#
# Prepares a new list in memory of values, used in
# configurations, payloads, and other areas
NEW_LIST() {
    local __v=_list_${1}_v

    declare -ga ${__v}

    eval "${__v}=()"
}

# ADD_LIST [name] [value]
#
# Adds to an existing list
ADD_LIST() {
    local __pv=_list_${1}_v
    local __v=${2}

    eval "${__pv}+=(\$__v)"
}

# LIST_TO_JSON_ARRAY [name]
#
# Convert a map to a flat JSON array of
# [ v1, v2, ..., vN ]
#
# Returns as string, to be captured with $(..)
LIST_TO_JSON_2DARRAY() {
    local __pv=_list_${1}_v

    eval "local __l=\${#${__pv}[@]}"
    eval "local __pv_v=(\${${__pv}[@]})"

    echo -n "["

    if test ${__l} -ge 1; then
        echo -n "\"${__pv_v[0]}\""
    fi

    for (( i = 1; i < ${__l}; i++ )); do
        echo -n ",\"${__pv_v[$i]}\""
    done

    echo -n "]"
}
