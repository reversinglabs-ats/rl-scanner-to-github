# pineapple helper library

. /lib/hak5/commands.sh
DUCKYSCRIPT_USER_DENIED=0
DUCKYSCRIPT_USER_CONFIRMED=1
DUCKYSCRIPT_CANCELLED=2
DUCKYSCRIPT_REJECTED=3
DUCKYSCRIPT_ERROR=4

# PINEAP_SSID_SSEN [ssid]
# Query the recon list for a SSID.  Must be an exact match.
#
# Return:
#  0			ssid has been seen
#  non-zero		ssid not seen
PINEAP_SSID_SEEN() {
	local __ssid="$1"

	local ret=$(/usr/bin/_pineap recon search "${__ssid}" limit=1)

	if [ "${ret}"x = "x" ]; then
		return 1
	fi

	return 0
}

# PINEAP_SSID_ISEEN [ssid]
# Query the recon list for a SSID.  Match is case insensitive
#
# Return:
#  0			ssid has been seen
#  non-zero		ssid not seen
PINEAP_SSID_ISEEN() {
	local __ssid="$1"

	local ret=$(/usr/bin/_pineap recon isearch "${__ssid}" limit=1)

	if [ "${ret}"x = "x" ]; then
		return 1
	fi

	return 0
}

# PINEAP_SSID_RSEEN [ssid]
# Query the recon list for a SSID.  Match is performed as an
# ECMAscript compatible regex
#
# Return:
#  0			ssid has been seen
#  non-zero		ssid not seen
PINEAP_SSID_RSEEN() {
	local __ssid="$1"

	local ret=$(/usr/bin/_pineap recon rsearch "${__ssid}" limit=1)

	if [ "${ret}"x = "x" ]; then
		return 1
	fi

	return 0
}

# PINEAP_SSID_IRSEEN [ssid]
# Query the recon list for a SSID.  Match is performed as an
# ECMAscript case-insensitive compatible regex
#
# Return:
#  0			ssid has been seen
#  non-zero		ssid not seen
PINEAP_SSID_IRSEEN() {
	local __ssid="$1"

	local ret=$(/usr/bin/_pineap recon irsearch "${__ssid}" limit=1)

	if [ "${ret}"x = "x" ]; then
		return 1
	fi

	return 0
}

_PINEAP_JQ_EXTRACTOR='.[] | ("MAC:\(.mac)", (.beacon | select (. != null) | to_entries | .[].value | "beacon",.channel,.count,.freq,.hidden,.signal,.ssid,.ssidlen,.time), (.response | select (. != null) | to_entries | .[].value | "response",.channel,.count,.freq,.signal,.ssid,.ssidlen,.time), (.probe | select (. != null) | to_entries | .[].value | select(.ssidlen != 0) | "probe",.channel,.count,.freq,.signal,.ssid,.ssidlen,.time))'

_PINEAP_SSID_MATCH_HANDLER() {
	local __function="$1"

	while read LINE; do
		case "$LINE" in
			"MAC"*)
				MAC=$LINE
				;;
			"beacon")
				read CHANNEL
				read COUNT
				read FREQ
				read HIDDEN
				read SIGNAL
				read SSID
				read SSIDLEN
				read TIME
				eval "${__function} ${MAC##MAC:} beacon \"${SSID}\" \"${SSIDLEN}\" \"${HIDDEN}\" \"${FREQ}\" \"${CHANNEL}\" \"${COUNT}\" \"${SIGNAL}\" \"${TIME}\""
				;;
			"response")
				read CHANNEL
				read COUNT
				read FREQ
				read SIGNAL
				read SSID
				read SSIDLEN
				read TIME
				HIDDEN=false
				eval "${__function} ${MAC##MAC:} response \"${SSID}\" \"${SSIDLEN}\" \"${HIDDEN}\" \"${FREQ}\" \"${CHANNEL}\" \"${COUNT}\" \"${SIGNAL}\" \"${TIME}\""
				;;
			"probe")
				read CHANNEL
				read COUNT
				read FREQ
				read SIGNAL
				read SSID
				read SSIDLEN
				read TIME
				HIDDEN=false
				eval "${__function} ${MAC##MAC:} probe \"${SSID}\" \"${SSIDLEN}\" \"${HIDDEN}\" \"${FREQ}\" \"${CHANNEL}\" \"${COUNT}\" \"${SIGNAL}\" \"${TIME}\""
				;;
			*)
				;;
		esac
	done
}

# PINEAP_SSID_MATCH [ssid] [function] {limit}
# Query the recon list for a SSID (exact match) and call the provided
# function for each SSID seen.
#
# Functions are called with the parameters:
# [mac] [type] [ssid] [ssid length] [hidden] [frequency] [channel] [packet count] [last signal] [last time unix]
PINEAP_SSID_MATCH() {
	local __ssid="$1"
	local __function="$2"
	local __limit="$3"
	local __limitcmd=""

	if [ "${__limit}"x != "x" ]; then
		__limitcmd="limit=${__limit}"
	fi

	/usr/bin/_pineap recon search "${__ssid}" format=json bytime=true ${__limitcmd} | \
		jq "${_PINEAP_JQ_EXTRACTOR}" --raw-output | _PINEAP_SSID_MATCH_HANDLER "${__function}"
}

# PINEAP_SSID_IMATCH [ssid] [function] {limit}
# Query the recon list for a SSID (case insensitive) and call the provided
# function for each SSID seen.
#
# Functions are called with the parameters:
# [mac] [type] [ssid] [ssid length] [hidden] [frequency] [channel] [packet count] [last signal] [last time unix]
PINEAP_SSID_IMATCH() {
	local __ssid="$1"
	local __function="$2"
	local __limit="$3"
	local __limitcmd=""

	if [ "${__limit}"x != "x" ]; then
		__limitcmd="limit=${__limit}"
	fi

	/usr/bin/_pineap recon isearch "${__ssid}" format=json bytime=true ${__limitcmd} | \
		jq "${_PINEAP_JQ_EXTRACTOR}" --raw-output | _PINEAP_SSID_MATCH_HANDLER "${__function}"
}

# PINEAP_SSID_RMATCH [ssid] [function] {limit}
# Query the recon list for a SSID (regular expression) and call the provided
# function for each SSID seen.
#
# Functions are called with the parameters:
# [mac] [type] [ssid] [ssid length] [hidden] [frequency] [channel] [packet count] [last signal] [last time unix]
PINEAP_SSID_RMATCH() {
	local __ssid="$1"
	local __function="$2"
	local __limit="$3"
	local __limitcmd=""

	if [ "${__limit}"x != "x" ]; then
		__limitcmd="limit=${__limit}"
	fi

	/usr/bin/_pineap recon rsearch "${__ssid}" format=json bytime=true ${__limitcmd} | \
		jq "${_PINEAP_JQ_EXTRACTOR}" --raw-output | _PINEAP_SSID_MATCH_HANDLER "${__function}"
}

# PINEAP_SSID_IRMATCH [ssid] [function] {limit}
# Query the recon list for a SSID (case insensitive regular expression) and
# call the provided function for each SSID seen.
#
# Functions are called with the parameters:
# [mac] [type] [ssid] [ssid length] [hidden] [frequency] [channel] [packet count] [last signal] [last time unix]
PINEAP_SSID_IRMATCH() {
	local __ssid="$1"
	local __function="$2"
	local __limit="$3"
	local __limitcmd=""

	if [ "${__limit}"x != "x" ]; then
		__limitcmd="limit=${__limit}"
	fi

	/usr/bin/_pineap recon irsearch "${__ssid}" format=json bytime=true ${__limitcmd} | \
		jq "${_PINEAP_JQ_EXTRACTOR}" --raw-output | _PINEAP_SSID_MATCH_HANDLER "${__function}"
}
